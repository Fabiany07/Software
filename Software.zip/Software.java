
import java.util.ArrayList;
import java.util.List;

public class Software {
    private String nome;
    private Versao versaoAtual;
    private List<Versao> historico = new ArrayList<>();

    public Software(String nome, Versao versaoAtual) {
        this.nome = nome;
        this.versaoAtual = versaoAtual;
        historico.add(versaoAtual);
    }

    public Versao getVersaoAtual() {
        return versaoAtual;
    }

    public void atualizar(Versao novaVersao) {
        versaoAtual = novaVersao;
        historico.add(novaVersao);
    }

    public void exibirHistorico() {
        System.out.println("Histórico de versões: " + historico);
    }
}
