
public class Main {
    public static void main(String[] args) {
        Versao versaoInicial = new Versao("1.0");

        Software software = new Software(
                "Sistema Smart TV", versaoInicial
        );

        SmartTV tv = new SmartTV("Modelo A", software);

        Versao novaVersao = new Versao("2.0");
        Atualizacao atualizacao = new Atualizacao(novaVersao);

        tv.exibirVersao();
        tv.verificarAtualizacao(atualizacao);
        tv.instalarAtualizacao(atualizacao);
        tv.exibirVersao();

    }
}
