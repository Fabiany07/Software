
public class SmartTV {
    private String modelo;
    private Software software;

    public SmartTV(String modelo, Software software) {
        this.modelo = modelo;
        this.software = software;
    }

    public void exibirVersao() {
        System.out.println(
                software.getVersaoAtual().getNumero()
        );
    }

    public void verificarAtualizacao(Atualizacao atualizacao) {
        String atual = software.getVersaoAtual().getNumero();
        String nova = atualizacao.getNovaVersao().getNumero();

        if (!atual.equals(nova)) {
            System.out.println("Existe uma atualização disponível!");
        } else {
            System.out.println("O software está atualizado.");
        }
    }

    public void instalarAtualizacao(Atualizacao atualizacao) {
        String atual = software.getVersaoAtual().getNumero();
        String nova = atualizacao.getNovaVersao().getNumero();

        if (atual.equals(nova)) {
            System.out.println("A TV já está atualizada.");
            return;
        }

        atualizacao.baixar();

        software = new Software("Sistema Smart TV",
                atualizacao.getNovaVersao());

        System.out.println("Atualização instalada com sucesso!");
    }
}
