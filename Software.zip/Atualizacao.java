public class Atualizacao {
    private Versao novaVersao;

    public Atualizacao(Versao novaVersao) {
        this.novaVersao = novaVersao;
    }

    public Versao getNovaVersao() {
        return novaVersao;
    }
    public void baixar() {
        System.out.println("Baixando atualização...");
    }
}