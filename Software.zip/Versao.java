public class Versao {
    private String numero;

    public Versao(String numero) {
        this.numero = numero;
    }

    public String getNumero() {
        return numero;
    }
}